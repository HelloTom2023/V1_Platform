/**********************************************************
 * @file        TDF8546_Ctl.c
 * @purpose    Functions of TDF8546 Control
 * @version    0.01
 * @date        17. Oct. 2013
 * @author    Deefisher.Lyu
 * @brief
 ***********************************************************
 *     History:                                                                       
 *  <write/modify>        <time>        <version >    <desc>           
 *  Deefisher.Lyu          17.Oct.2013        v0.01        created
 *  
  **********************************************************/
#define TDF8546_CTL_C
/* ========================= File include ======================= */
#include "..\..\config\inc.h"
/* ========================= Function Announcement  =================== */
#ifdef D_AMP_TDF8546
/* ========================= public variable ==================== */

/* ========================= private variable =================== */

/* ========================= Code Part =================== */

/**********************************************************
 * @function    TDF8546_InitVariable
 * @brief      Initialize Variable
 * @param      None                    
 * @retval     Result
 **********************************************************/
void TDF8546_InitVariable(void)
{
     sTDF8546.Ready = 0;
     sTDF8546.Step = 0;
     sTDF8546.Delay = 0;
     sTDF8546.DrvStep = 0;
}
/**********************************************************
 * @function    TDF8546_OpenPower
 * @brief      Open  Power
 * @param      None                    
 * @retval     Result
 **********************************************************/
uint8_t TDF8546_OpenPower(void)
{
    return (SUBLAYER_DONE);
}
/**********************************************************
 * @function    TDF8546_Reset
 * @brief     
 * @param      Null
 * @retval     Result
 **********************************************************/
uint8_t TDF8546_Reset(void)
{
    uint8_t Result = SUBLAYER_DOING;
    uint8_t SubResult = SUBLAYER_DOING;
    uint8_t QueueResult = FALSE;

    if(DelayNotExpired(sTDF8546.Delay))
    {
        return (SUBLAYER_DOING);
    }
#ifndef D_CODE_FOR_JX

    if(MODULE_NONE == sTDF8546.Module)
    {
        return (SUBLAYER_DONE);
    }
    
#endif
    switch(sTDF8546.Step)
    {
        //Check IIC Bus Status
        case TDF8546_RST_CHK_BUS:    //Check Related IIC Task Status
            if(OS_TaskIsActive(TASK_ID_I2C2))
            {
                sTDF8546.Step = TDF8546_RST_CHK_DEV;
            }
            else
            {
                SubResult = OS_TaskStart(TASK_ID_I2C2);
                if(TRUE == SubResult)
                {
                    sTDF8546.Step = TDF8546_RST_CHK_DEV;
                    sTDF8546.ChkCnt = 0;
                }
                else
                {    //Re-Check Bus
                    //sTDF8546.Delay = TDF8546Delay(T50MS);
                }
            }
            IO_Set(IO_IDX_AMP_STANDBY,PIN_OUTPUT,INVALID);
            sTDF8546.Delay = TDF8546Delay(T20MS);
            break;

        //Check AK Device Status
        case TDF8546_RST_CHK_DEV:
            sTDF8546.DrvResult = I2C_RET_WAIT;
            QueueResult = I2C_CheckDevice(TDF8546_IIC,TDF8546_CS_ADDR,TRUE,(void *)TDF8546_CallBack_Common,I2C_74KBPS);    
            if(TRUE == QueueResult)  //Command Successfully Queued in IIC Buffer...
            {
                sTDF8546.Step = TDF8546_RST_END;    
            }
            else
            {    // Failed to Queue in IIC Buffer...  Retry Later...
                //...
                sTDF8546.Step = OPERATION_0;
            }
            break;

        //Reset Ends!
        case TDF8546_RST_END:
            if(I2C_RET_SUCCESS == sTDF8546.DrvResult)
            {
                Result = SUBLAYER_DONE;
            }
            else if(I2C_RET_ERR == sTDF8546.DrvResult)
            {
             #if 0
                if(sTDF8546.ChkCnt > 100)
                {
                    Result = SUBLAYER_DONE;
                    sTDF8546.Step = OPERATION_0;
		#ifndef D_CODE_FOR_JX		/*Add by zwl, JX Amplifier fixed to TDF8546 */
                    sTDF8546.Module = MODULE_NONE;
		#endif
		      Amp_printf(_T("8546failed,not exist!\n"));
                }
                else
                {
                    sTDF8546.ChkCnt++;
                    sTDF8546.Step = TDF8546_RST_CHK_DEV;  
                    sTDF8546.Delay = TDF8546Delay(T20MS);
		      Amp_printf(_T("8546 recheck!\n"));
                }
		#else /*ADD by keilee*/
		      sTDF8546.Step = TDF8546_RST_CHK_DEV;  
                    sTDF8546.Delay = TDF8546Delay(T20MS);
		      Amp_printf(_T("8546 recheck!\n"));
		#endif
            }
            break;

        default:
            Result = SUBLAYER_STEP_ERROR;
            sTDF8546.Step = OPERATION_0;
            break;
    }

    //Error Occurs...
    if(SubResult > SUBLAYER_DONE)
    {
        Result = SubResult;
        sTDF8546.Step = OPERATION_0;
    }    

    return (Result);
}
/**********************************************************
 * @function    TDF8546_Register
 * @brief      Initialize TDF8546's Registers
 * @param      None                    
 * @retval     Result
 **********************************************************/
uint8_t TDF8546_Register(void)
{
    uint8_t Result = SUBLAYER_DOING;
    uint8_t Buffer[5];

    Buffer[0] = DEFAULT_IB1;
    Buffer[1] = DEFAULT_IB2;
    Buffer[2] = DEFAULT_IB3;
    Buffer[3] = DEFAULT_IB4;
    Buffer[4] = DEFAULT_IB5;

    if(MODULE_NONE == sTDF8546.Module)
    {
        return (SUBLAYER_DONE);
    }

    Result = TDF8546_WriteCommon(Buffer,5);
    
    if(Result == SUBLAYER_DONE)
    {
        sTDF8546.Ready = 1;
    }
    
    return (Result);
}
/**********************************************************
 * @function    TDF8546_Mute
 * @brief      
 * @param      uint8_t Mode                    
 * @retval     Result
 **********************************************************/
uint8_t TDF8546_Mute(uint8_t Mode)
{
    uint8_t Result = SUBLAYER_DOING;
    uint8_t Buffer[5];

    Buffer[0] = DEFAULT_IB1;
    if(MUTE_ON == Mode)
    {
       Buffer[1] = DEFAULT_IB2;
    }
    else
    {
        Buffer[1] &= (~ TDF8546_MUTE);
    }
    Buffer[2] = DEFAULT_IB3;
    Buffer[3] = DEFAULT_IB4;
    Buffer[4] = DEFAULT_IB5;

    if(MODULE_NONE == sTDF8546.Module)
    {
        return (SUBLAYER_DONE);
    }

    Result = TDF8546_WriteCommon(Buffer,5);
    
    return (Result);    
}
/**********************************************************
 * @function    TDF8546_Detect
 * @brief      Detect TDF status
 * @param    NULL                 
 * @retval     NULL
 **********************************************************/
void TDF8546_Detect(void)
{
    uint8_t Result = SUBLAYER_DOING;
    
    if(AUDIO_SYS_RUN != AudioGetSysState())
    {
        return;
    }    
    
    if(DelayNotExpired(sTDF8546.Delay))
    {
        return;
    }    

    if(MODULE_NONE == sTDF8546.Module)
    {
        return;
    }

    Result = TDF8546_ReadCommon();
    if(SUBLAYER_DONE == Result)
    {
        sTDF8546.Delay = AudioDelay(T5S);
        if(IO_Get(IO_IDX_AMP_CLIP,PIN_INPUT,TRUE))
        {
                //Clip Detected
         #ifdef UDS_ENABLE_MACRO
		 Uds_UpdateDTCStatus(DTC_ID_AMP_CLIP, 0x08);
	  #endif
        }
        else
        {
	  #ifdef UDS_ENABLE_MACRO
		 Uds_UpdateDTCStatus(DTC_ID_AMP_CLIP, 0x00);
	  #endif
        }
        //Analyse TDF status data
         #ifdef UDS_ENABLE_MACRO
        if((sTDF8546.DrvRead[0] & 0x30) == 0x00)
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_FL_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_FL_OC, 0x00);
	 }
	 else if((sTDF8546.DrvRead[0] & 0x30) == 0x20)			//open circle
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_FL_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_FL_OC, 0x08);
	 }
	 else
	 {
		Uds_UpdateDTCStatus(DTC_ID_SPK_FL_SC, 0x08);
		Uds_UpdateDTCStatus(DTC_ID_SPK_FL_OC, 0x00);
	 }

	 if((sTDF8546.DrvRead[1] & 0x30) == 0x00)
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_RR_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_RR_OC, 0x00);
	 }
	 else if((sTDF8546.DrvRead[1] & 0x30) == 0x20)			//open circle
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_RR_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_RR_OC, 0x08);
	 }
	 else
	 {
		Uds_UpdateDTCStatus(DTC_ID_SPK_RR_SC, 0x08);
		Uds_UpdateDTCStatus(DTC_ID_SPK_RR_OC, 0x00);
	 }

	 if((sTDF8546.DrvRead[2] & 0x30) == 0x00)
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_RL_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_RL_OC, 0x00);
	 }
	 else if((sTDF8546.DrvRead[2] & 0x30) == 0x20)			//open circle
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_RL_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_RL_OC, 0x08);
	 }
	 else
	 {
		Uds_UpdateDTCStatus(DTC_ID_SPK_RL_SC, 0x08);
		Uds_UpdateDTCStatus(DTC_ID_SPK_RL_OC, 0x00);
	 }

	 if((sTDF8546.DrvRead[3] & 0x30) == 0x00)
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_FR_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_FR_OC, 0x00);
	 }
	 else if((sTDF8546.DrvRead[3] & 0x30) == 0x20)			//open circle
        {
		Uds_UpdateDTCStatus(DTC_ID_SPK_FR_SC, 0x00);
		Uds_UpdateDTCStatus(DTC_ID_SPK_FR_OC, 0x08);
	 }
	 else
	 {
		Uds_UpdateDTCStatus(DTC_ID_SPK_FR_SC, 0x08);
		Uds_UpdateDTCStatus(DTC_ID_SPK_FR_OC, 0x00);
	 }
			
       // CANUser_DebugInfoOutput(0, sTDF8546.DrvRead, 5);
        #endif
    }
    else if(SUBLAYER_ERROR == Result)
    {
        sTDF8546.Delay = AudioDelay(T5S);
    }
}



#endif//D_AMP_TDF8546

