/**********************************************************
 * @file        TDF8546_Ctl.h
 * @purpose    Definition of TDF8546 Control
 * @version    0.01
 * @date        17.Oct. 2013
 * @author    Deefisher.Lyu
 * @brief
 ***********************************************************
 *     History:                                                                       
 *  <write/modify>        <time>        <version >    <desc>           
 *    Deefisher.Lyu        17.Oct.2013              v0.01        created
 *  
  **********************************************************/
#ifndef TDF8546_CTL_H
#define TDF8546_CTL_H

#ifdef D_AMP_TDF8546

#ifdef TDF8546_CTL_C
#define EXTERN 
#else
#define EXTERN extern 
#endif//TDF8546_CTL_C

#if D_DEBUG_AMP&& D_PRINT_EN
#define Amp_printf(x)  x
#else
#define Amp_printf(x)
#endif

//............................................................................................
//4 TDF8546 Control Step Definitions : Start

// TDF8546 Reset Step
typedef enum tdf8546_rst_step_enum
{
    TDF8546_RST_CHK_BUS = 0,        //Check BUS Status
    TDF8546_RST_CHK_DEV,        // Check Device Status
    TDF8546_RST_END,            // Reset End
}TDF8546_RST_STEP_ENUM;

//4 TDF8546 Control Step Definitions : End
//............................................................................................



//--------------------------------------------------------------
//3  Declare :Start

EXTERN void TDF8546_InitVariable(void);
EXTERN uint8_t TDF8546_OpenPower(void);
EXTERN uint8_t TDF8546_Reset(void);
EXTERN uint8_t TDF8546_Register(void);
EXTERN uint8_t TDF8546_Mute(uint8_t Mode);
EXTERN void TDF8546_Detect(void);

//3  Declare :End
//--------------------------------------------------------------

#undef EXTERN
#endif//D_AMP_TDF8546
#endif//TDF8546_CTL_H

