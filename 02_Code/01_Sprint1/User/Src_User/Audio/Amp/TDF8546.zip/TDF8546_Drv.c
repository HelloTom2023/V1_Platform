/**********************************************************
 * @file        TDF8546_Drv.c
 * @purpose    Functions of TDF8546 Driver
 * @version    0.01
 * @date        17. Oct. 2013
 * @author    Deefisher.Lyu
 * @brief
 ***********************************************************
 *     History:                                                                       
 *  <write/modify>        <time>        <version >    <desc>           
 *  Deefisher.Lyu          17.Oct.2013        v0.01        created
  **********************************************************/
#define TDF8546_DRV_C
/* ========================= File include ======================= */
#include "..\..\config\inc.h"
/* ========================= Function Announcement  =================== */
#ifdef D_AMP_TDF8546
/* ========================= public variable ==================== */

/**********************************************************
 * @function    TDF8546_CallBack_Common
 * @brief      TDF8546 Common CallBack Function
 *                 Get Result of Currently IIC Command
 * @param      uint8_t eState                    
 * @retval     Result
 **********************************************************/
uint8_t TDF8546_CallBack_Common(uint8_t Result)
{
    sTDF8546.DrvResult = Result;

    return (0); //IIC Driver Use: Do not Reset IIC
}
/**********************************************************
 * @function    TDF8546_WriteCommon
 * @brief         Commonly Write Datum to TDF8546, Only one Packet     
 * @param       uint8_t* Dat  
 *                  uint8_t Num 
 * @retval     Result
 **********************************************************/
uint8_t TDF8546_WriteCommon(uint8_t* Dat, uint8_t Num)
{
    uint8_t Result = SUBLAYER_DOING;
    uint8_t QueueResult = FALSE;
    
    switch(sTDF8546.DrvStep)
    {
        // Send Datum if Bus is Idle
        case OPERATION_0:
            sTDF8546.DrvResult = I2C_RET_WAIT;
            Memcpy_U8(Dat,sTDF8546.DrvBuff,Num);
            QueueResult = TDF8546_WritePdat(sTDF8546.DrvBuff,Num,(void *)TDF8546_CallBack_Common);
            if(TRUE == QueueResult) //Command Successfully Queued in IIC Buffer...
            {
                sTDF8546.DrvOverTime = TDF8546Delay(T100MS);
                sTDF8546.DrvStep = OPERATION_1;
            }
            else
            {    // Failed to Queue in IIC Buffer...
                //....
            }
            break;

        //Check Result
        case OPERATION_1:
            if(I2C_RET_SUCCESS == sTDF8546.DrvResult)
            {
                Result = SUBLAYER_DONE;
            }
            else if((I2C_RET_ERR == sTDF8546.DrvResult) || (OverTimeExpired(sTDF8546.DrvOverTime)))
            {
                Result = SUBLAYER_ERROR;
            }
            break;
            
        default:
            Result = SUBLAYER_STEP_ERROR;
            break;
    }

    //Err Occurs!
    if(Result >= SUBLAYER_DONE)
    {
        sTDF8546.DrvStep = OPERATION_0;
    }
    
    return (Result);
}
/**********************************************************
 * @function    TDF8546_ReadCommon
 * @brief      Commonly read from register
 * @param      
 * @retval     result of execute
 **********************************************************/
uint8_t TDF8546_ReadCommon(void)
{
    uint8_t Result = SUBLAYER_DOING;
    uint8_t QueueResult = FALSE;

    switch(sTDF8546.DrvStep)
    {
        // Send Datum if Bus is Idle
        case OPERATION_0:
            sTDF8546.DrvResult = I2C_RET_WAIT;
            QueueResult = TDF8546_Read(sTDF8546.DrvRead,5,(void *)TDF8546_CallBack_Common);
            if(TRUE == QueueResult) //Command Successfully Queued in IIC Buffer...
            {
                sTDF8546.DrvOverTime = TDF8546Delay(T100MS);
                sTDF8546.DrvStep = OPERATION_1;
            }
            else
            {    // Failed to Queue in IIC Buffer...
                //....
            }
            break;

        //Check Result
        case OPERATION_1:
            if(I2C_RET_SUCCESS == sTDF8546.DrvResult)
            {
                Result = SUBLAYER_DONE;
            }
            else if((I2C_RET_ERR == sTDF8546.DrvResult) || (OverTimeExpired(sTDF8546.DrvOverTime)))
            {
                Result = SUBLAYER_ERROR;
            }
            break;
            
        default:
            Result = SUBLAYER_STEP_ERROR;
            break;
    }

    //Err Occurs!
    if(Result >= SUBLAYER_DONE)
    {
        sTDF8546.DrvStep = OPERATION_0;
    }
    
    return (Result);
}
#endif//D_AMP_TDF8546
