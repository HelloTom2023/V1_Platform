/**********************************************************
 * @file        TDF8546_Drv.h
 * @purpose    Definition of TDF8546 Driver
 * @version    0.01
 * @date        17.Oct. 2013
 * @author    Deefisher.Lyu
 * @brief
 ***********************************************************
 *     History:                                                                       
 *  <write/modify>        <time>        <version >    <desc>           
 *    Deefisher.Lyu        17.Oct.2013              v0.01        created
 *  
  **********************************************************/
#ifndef TDF8546_DRV_H
#define TDF8546_DRV_H

#ifdef D_AMP_TDF8546
#ifdef TDF8546_DRV_C
#define EXTERN 
#else
#define EXTERN extern 
#endif//TDF8546_DRV_C

//............................................................................................
//4 TDF8546 IIC Related---Start

/*
ADSEL--Resistor--ADD 
            10K         D4
            30K         DE
            100K        DC
            5V          DA
--------------------------------*/
#ifdef D_AMP_TDF75610
#define TDF8546_CS_ADDR     0xD8    // Chip Selection Address     
#else
#define TDF8546_CS_ADDR     0xD4    // Chip Selection Address     
#endif
#define TDF8546_IIC    I2C2 //Used I2c Port
#define TDF8546_WriteDat(Dat,Num,CallBack) I2C_Write(TDF8546_IIC,TDF8546_CS_ADDR,FALSE,Dat,Num,TRUE,CallBack,I2C_74KBPS)
#define TDF8546_WritePdat(Dat,Num,CallBack) I2C_Write(TDF8546_IIC,TDF8546_CS_ADDR,TRUE,Dat,Num,TRUE,CallBack,I2C_74KBPS)
#define TDF8546_ReadDat(Dat,Num,CallBack)    I2C_ReadFromSubAdd(TDF8546_IIC,TDF8546_CS_ADDR,0x00,FALSE,Dat,Num,TRUE,CallBack,I2C_74KBPS)
#define TDF8546_ReadPdat(Dat,Num,CallBack) I2C_ReadFromSubAdd(TDF8546_IIC,TDF8546_CS_ADDR,0x00,TRUE,Dat,Num,TRUE,CallBack,I2C_74KBPS)
#define TDF8546_Read(Dat,Num,CallBack)  I2C_Read(TDF8546_IIC,TDF8546_CS_ADDR,TRUE,Dat,Num,TRUE,CallBack,I2C_74KBPS)
//4 TDF8546 IIC Related---End
//............................................................................................

//-------------------------------------------------------
//2 TDF8546 Related Def: Start

#define DEFAULT_IB1 0x07//0x83
#define DEFAULT_IB2 0x77//0x47    //Default Mute
#define DEFAULT_IB3 0x10//0x00
#define DEFAULT_IB4 0x01//0x24
#define DEFAULT_IB5 0x90 //0x90   // 0x00 Disable Best Efficiency   


//2 TDF8546 Related Def: End
//-------------------------------------------------------


#pragma pack(1)
// Struct
typedef struct tdf8546_struct
{
    uint8_t Ready;     //device ready to control    
    uint8_t Module;
    //Driver Control
    uint8_t DrvStep;        //Driver Control Step
    uint8_t DrvResult;    //Driver Execute Result 
    uint8_t DrvOverTime;
    uint8_t DrvBuff[5];
    uint8_t DrvRead[5];
    // Ak Control
    uint8_t Step;
    uint16_t Delay;
    uint8_t ChkCnt;
}TDF8546_STRUCT;

#define TDF8546_TICK_BASE        2
#define TDF8546Delay(x)            (x)/TDF8546_TICK_BASE

//--------------------------------------------------------------
//3  Declare :Start

EXTERN TDF8546_STRUCT sTDF8546;
EXTERN uint8_t TDF8546_CallBack_Common(uint8_t Result);
EXTERN uint8_t TDF8546_WriteCommon(uint8_t* Dat, uint8_t Num);
EXTERN uint8_t TDF8546_ReadCommon(void);
//3  Declare :End
//--------------------------------------------------------------

#define AMP_IB1 sTDF8546.RegBuff[0]
#define AMP_IB2 sTDF8546.RegBuff[1]
#define AMP_IB3 sTDF8546.RegBuff[2]
#define AMP_IB4 sTDF8546.RegBuff[3]
#define AMP_IB5 sTDF8546.RegBuff[4]

#define AMP_ENABLE      0x01
#define TDF8546_MUTE        0x07
#define TDF8546_UNMUTE      0x00

#define AMP_FL  0
#define AMP_FR  1
#define AMP_RL  2
#define AMP_RR  3

#define TDF8546_CH1 AMP_RL
#define TDF8546_CH2 AMP_FL
#define TDF8546_CH3 AMP_FR
#define TDF8546_CH4 AMP_RR

#define OVER_TEMP   0x80
#define SPEAKER_FAULT   0x40
#define OPEN_LOAD   0x20
#define SHORTED_LOAD    0x08
#define OUTPUT_OFFSET   0x04
#define SHORT_TO_VP     0x02
#define SHORT_TO_GND    0x01

#define UNDER_VOLTAGE   0x80
#define OVER_VOLTAGE       0x40
#define SYSTEM_BUSY     0x20
#define VP_BELOW_75     0x10
#define VP_BELOW_10     0x08


#undef EXTERN
#endif//D_AMP_TDF8546
#endif//TDF8546_DRV_H

